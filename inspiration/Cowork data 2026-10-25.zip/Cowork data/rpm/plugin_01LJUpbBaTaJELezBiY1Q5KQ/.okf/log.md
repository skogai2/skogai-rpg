# Update Log

## 2026-09-21
* **Repo hygiene**: README rewritten around one thread (what OKF is, install per channel, use, what's inside, format, measured results as bullets with links, contributing, credits); the layout tree and duplicate install block are gone, counts and CI rules match the code, and the backfill's dependency on the plugin-only `agents/` is stated. Drift fixed alongside: `make test` runs the gate tests, CI's shipped and `.okf` regexes cover `agents/`, the inert `benchmark/trust/runs/` ignore rule is dropped, the root index links the backfill skill and a new concept for `okf_backfill_events.py`, and the backfill concept documents the two agents.
* **Release 0.9.6**: the vendored spec was resynced with upstream, which moved to
  `GoogleCloudPlatform/open-knowledge-format` (the old `knowledge-catalog/okf`
  location is a frozen snapshot) and made three date fields — `stale_after`,
  `sources[].last_modified`, `usage_window.{from,to}` — ISO 8601 datetimes with
  an explicit offset. The validator now accepts a datetime on all three (a bare
  date is still tolerated, no new warnings on existing bundles); the visualizer
  compares staleness as instants (`Date.parse(stale_after) <= Date.now()`)
  instead of a string compare, so a datetime value reads stale on the right
  instant instead of never matching; the backfill weaver's frontmatter contract
  now asks for the event's full ISO 8601 timestamp in `sources[].last_modified`
  instead of a truncated `YYYY-MM-DD`, retiring the workaround from the map-phase
  decision. Also fixed: the weaver's "process events in order" instruction told
  it to rely on the filename sort of `analyses/*.md`, but analysis filenames are
  event ids (content hashes) — their lexical order has no relation to time. It
  now names the live-event-id list and the frontmatter `timestamp` instead.
* **Release 0.9.5**: a reconstructed bundle no longer declares itself stable nor
  keeps asserting states its own history has overturned. Text-only: no script,
  no flag, no new surface. The fix came from outside, from a bundle built with
  the skill on a presales repo, where the second layer written by hand
  contradicted the first layer written by the replay.
* **Backfill skill** (`/skills/backfill.md`): a reconstructed bundle stopped
  declaring itself ready to use and stopped asserting states the history had
  already overturned. Reported from a real reconstruction in another repo, where
  two concepts born of the same replay contradicted each other in the present
  tense and both passed the validator in strict mode. Three causes, all in the
  skill text: the weaver's frontmatter contract had no `status`, and §5.4 reads an
  absent one as `stable`; "update over create" is a merge rule and says nothing
  about a reversal, so the later event created a sibling instead of replacing;
  every guard was lexical, and the coverage check pushed toward keeping superseded
  material rather than retiring it. The sister `okf` skill already had the right
  rule in maintain mode (mark `deprecated`, note it in the log, never delete
  silently); backfill is maintain replayed over history and had not inherited it.
  The semantic check sits at fold time, not in a finalize reread: the weaver
  already holds the analysis and every earlier concept there, and a second full
  pass would buy defense in depth at the price of rereading the bundle.

## 2026-09-05
* **Release 0.9.4**: the capped diff emitter, counts-only contracts, batched
  dispatch and the haiku analyzer default, with the map-tier benchmark that
  decided them. No new surface: the backfill skill reads less, says what it
  read, and costs about a third less per full reconstruction of this history.
* **Backfill map phase routed like a bulk read**: the analyzer never runs a raw
  `git show` again. The extractor gained `--show <sha>`, a capped diff emitter
  that reads the whole first-parent diff and emits a deterministic sample
  (complete stat, per-file caps cut at hunk boundaries, generated files' patches
  dropped in mixed commits, over-long lines shortened, a fixed last line that
  declares `truncated=true|false`). The reason is the harness: long tool output
  is cut blindly, mid-hunk and host-dependently, and a cheap worker may not
  notice; a script that read everything can choose what survives, and say so.
  `docs/self.html` made the character cap necessary (one 61,537-character line
  counts as "1+1" in numstat). Contracts tightened around it: the orchestrator
  dispatches ids and reads counts only, analyzers fetch their own events with
  `jq` and reply one line per event, the weaver replies counts; the cost note no
  longer claims 64-way parallelism, which the gate benchmark's mass failure had
  already disproved. The tier of the analyzer is being measured rather than
  assumed: `benchmark/map-tier/PROTOCOL.md` fixes the arms, metrics and decision
  rules before the run.
* **Map-phase routing measured** ([decision](decisions/map-phase-routing.md),
  `benchmark/map-tier/RESULTS.md`): four arms on this repository's 147 live
  events, 436 agents, zero errors. Batching small events eight per call ships:
  57 calls instead of 147, a third off the map phase at the same tier, no loss on
  any paired per-event metric and no cross-event contamination. The cheap tier
  extracted commits at parity with sonnet and failed two pre-set rules in run 1,
  both contract failures of an under-specified instruction (it copied the last
  summary line it saw; it filled thin session evidence with the plausible
  continuation); the instructions are now explicit in the analyzer file and were
  re-measured in runs 2 and 3. The weaver's `last_modified` contract now asks for
  a date, because every arm's `--strict` run warned on the timestamp. The reduce
  phase costs as much as a sonnet map in every arm, which makes the weaver's
  context shape the next lever, not the analyzer tier. Run 3 passed every pre-set
  rule with both instructions explicit, the truncation flag at the threshold
  (0.905): the analyzer's default tier is now `haiku`, batched, about 30 dollars
  per full backfill of this history against 46, the reduce phase unchanged.

## 2026-09-03
* **Release 0.9.3**: the two benchmarks, the README section that leads with
  their qualifications, and CI gating both suites. No change to what the plugin
  does; what changed is the evidence shipped beside it.
* **Both benchmarks land in `main`, and the README says what they measured**:
  a "What has actually been measured" table pointing at the two results files,
  written so the honest part is the part you read first — the trust benchmark's
  primary contrast is invalid under its own rule, and the gate benchmark cannot
  distinguish the two mechanisms it compared. CI now gates the gate benchmark's
  tests alongside the trust benchmark's, for the same stated reason: its
  analysis decides whether a published comparison is honest.
* **Gate benchmark ([#48](https://github.com/scaccogatto/okf-skills/issues/48)), the question #40 left open**: does a
  write-side process gate beat read-side trust metadata? Protocol, two-stage
  harness and analysis in `benchmark/gate/`, pre-registered at
  `gate-benchmark-prereg-rev1`. Stage E is in: with an `AGENTS.md` gate the
  writer touched the documentation 100 times out of 100 and the consumer
  asserted the superseded fact 9% of the time; without it, 43 out of 100 and
  48%. A 39.0pp reduction, CI [21.0, 58.0]. Two probes ran before the protocol
  was frozen and are excluded from the result — one of them estimated
  spontaneous syncing at 5 of 6, which did not survive contact with 100 runs
  (43 of 100), which is exactly why probe data is declared out of the result
  rather than folded into it. The read side came in at 62% stale unmarked, 34%
  with only an expired `stale_after`, 27% marked `deprecated`: a 28.0pp
  reduction from the one field that expires without anyone acting. Compared
  directly on the same items, write side minus read side is +11.0pp
  CI[-10.0, +33.0] — **both mechanisms work and this experiment cannot tell them
  apart**, so neither makes the other redundant. Result in
  `benchmark/gate/RESULTS.md`; the answer to #40's §14 is "neither, both", and
  the question that actually separates them (six months of drift) is one no
  per-trial harness can see.

## 2026-09-02
* **Trust benchmark, the result**: it ran. Pre-registration frozen at
  `trust-benchmark-prereg-rev8`, 946 measurement trials, writeup in
  `benchmark/trust/RESULTS.md`, every trial record published. **The primary
  result is invalid by the protocol's own §3.2 rule** (16.3% of items have no
  committed answer in a primary arm, against a 10% ceiling), and the effect it
  would have reported is at the ceiling: 97.7pp, 93.7pp under the punitive worst
  case. One cause for both, and it is the interesting part — the control does
  not answer wrongly, it declines: 116 of its 123 `neither` are the literal
  token `unknown`. The two readings worth more than the headline: the
  instruction alone does nothing (B1 − B0 = 0.0pp) and the metadata alone does
  everything (A0 − B0 = −97.7pp). Recorded with it: a sign error in the
  committed analysis that would have called a perfect result a failure, found by
  the first real result rather than by reading, corrected post-run only because
  §3.2 had already invalidated the verdict it could have flipped. See the
  [decision](/decisions/trust-benchmark.md).
* **Trust benchmark, two defects the results would never have shown**: the
  first calibration ran, and the first thing it produced was evidence against
  the harness rather than about the spec. Asked to quote what preceded its
  prompt, a trial read back this machine's SessionStart hook, its persona
  instruction and the maintainer's global `CLAUDE.md`: `--settings '{"hooks":
  {}}'` merges rather than clears, so revision 6's isolation claim was false
  while every trial ran identically contaminated. `--safe-mode` is the flag that
  holds, and those 192 trials were discarded rather than reused. The second
  defect was in the corpus: 0 of 48 items trapped, and a control trial explained
  why — *"every `*-notes.md` file is an update layer reporting current state"*.
  The replacements announced their own recency in prose, and shared a filename
  convention that ranked every pair in all four arms, which is the revision-1
  defect of §6 reappearing as a naming convention. Corpus v2 puts the
  replacement in a document about an adjacent topic with no temporal prose and
  balanced filenames; one rewritten item went from 1/4 to 4/4 stale in B0.
  Also §9: the forced field now demands a bare value and offers
  `ANSWER: unknown`, because "The higher-priority task (priority descending)"
  asserts the value and grades `neither`, losing an item for a reason that has
  nothing to do with what it measures.

## 2026-09-01
* **Trust benchmark, the corpus**: the 48 candidates of §6 are authored — six
  supersession shapes (limit changed, default flipped, renamed identifier,
  reversed recommendation, removed capability, changed precedence), eight items
  each, over invented systems so no answer can come from pretraining. Every pair
  obeys §4 by construction: the superseded document is the *more* attractive
  answer (longer, more specific on the fact under test, in the question's exact
  terminology) and the replacement mentions the fact in passing, so the only
  signal separating them is the frontmatter. 192/192 calibration trials pass
  preflight, which also caught the one authoring defect worth recording: an item
  whose question named both candidate answers, i.e. leaked the contrast into a
  channel present in every arm. Still nothing has been run — the runner needs
  Anthropic API credentials this environment does not have.
* **Fix**: [backfill](/skills/backfill.md) `repo_slug()` now maps every
  non-alphanumeric character to a dash, matching Claude Code's real transcript
  dir naming (`p-045_ekar_skills` -> `p-045-ekar-skills`); underscores in the
  repo path previously yielded zero session events. Plugin 0.9.0 to 0.9.1.
* **Fix**: The [backfill](/skills/backfill.md) extractor and its tests are now
  Windows-portable: `repo_slug()` maps `\` and drive colons to dashes alongside
  `/` and `.`, the cwd filter compares `Path`s instead of string prefixes, and
  the tests use a real resolvable temp path plus a `__file__`-derived cwd
  instead of a hardcoded machine-local worktree path (which broke CI on both
  runners).
* **Trust benchmark, revision 4 and the first executable pieces**: the
  [protocol](/decisions/trust-benchmark.md) gained a harness, a grader, an
  analysis script and a frozen item format; still nothing has been run. The
  revision was forced by checking §8 against the API rather than against memory:
  `claude-opus-5` rejects `temperature` with a 400 and the Messages API has no
  seed parameter, so the section written specifically to remove placeholders had
  frozen two values that do not exist. `effort` and `thinking` are pinned in
  their place, and per-trial response ids replace the seeds §13 promised to
  publish. Revision 5 followed immediately, from the same habit of checking §8
  against something: its injected-date rule ("later than every `stale_after` in
  the corpus") contradicted the distractor-straddling rule one bullet up and
  marked the *replacement* document stale too, leaving the treatment arm no
  fresh answer to give. Both defects lived in the section written specifically
  to stop that class of failure.
* **Dogfooding**: Armed the [dormant Stop hook](/decisions/dormant-hooks.md) on
  this repo. `.okf/index.md` now carries `upkeep: enforced`, so the plugin's own
  hook blocks a session that changed tracked files without touching
  `.okf/log.md`. The bundle shipping the enforcement mechanism was the one repo
  not using it, relying instead on a maintainer's machine-level hook that no
  contributor has.
  Arming it surfaced a second defect: the [validator](/components/validator.md)
  warned `§12 root index.md frontmatter may only carry \`okf_version\``, so any
  enforced-mode bundle failed its own `--strict` run. `upkeep` is now allowed
  next to `okf_version`.
* **Documentation**: Full freshness audit of every human-facing surface (README,
  CHANGELOG, the three `SKILL.md` files, this bundle, `action.yml` and the
  workflows), each claim re-checked against the code it describes. 42 verified
  defects, of which five were wrong rather than merely stale: `--strict` was
  documented as never blocking on warnings while the commands shown beside it
  pass `--strict`; the visualizer's bundle argument was documented as optional
  and is required; nodes were documented as sized by type and are sized by body
  length; "no data leaves the page" omitted the three CDN libraries the rendered
  page loads. The changelog had drifted three releases behind `plugin.json`,
  which is what motivated the CI gate below. Two shipped assets turned out to
  have no concept at all and now do: [ci.yml](/components/ci-workflow.md) and
  [action.yml](/components/github-action.md).
* **Release**: The floating `v1` tag now follows every release
  ([release.yml](/components/release-workflow.md)). It had been created by hand
  on a docs commit and never moved, so the README's own action example ran a
  validator from 0.6.0, one that rejects the `upkeep` flag the README tells
  adopters to add. Pinning the README to an exact tag was the alternative and
  was rejected: it is another thing someone has to remember, which is precisely
  how this drifted.
* **Enforcement**: Mirrored the [Stop hook](/components/stop-hook.md)'s two
  obligations into CI, as steps on the existing `version-bump` job. A PR that
  touches `skills/*/scripts/**` or `hooks/**` must also touch `.okf/`, and a PR
  that bumps the version must add the matching `CHANGELOG.md` heading. The hook
  only reaches people running the plugin; a contributor on a plain checkout had
  no obligation at all, which is how the changelog drifted three releases behind
  `plugin.json` unnoticed.
* **Message**: The §11.1 error now names its fix. A third-party bundle shipping
  an `AGENTS.md` next to its concepts was told only "no parseable YAML
  frontmatter block", which is true and useless to someone who never meant that
  file as a concept. The [validator](/components/validator.md) now points at the
  two ways out (add a `type`, or move the file outside the bundle). Exempting
  convention filenames was rejected: §11.1 covers every non-reserved `.md` in the
  tree, so a skip-list would make the checker itself non-conformant (v0.7.3).
* **Bugfix**: The backfill skill's session-transcript extractor
  (`skills/backfill/scripts/okf_backfill_events.py`) was written against an
  invented transcript schema and its tests matched the bug instead of real
  files. Rewrote `sessions_from_transcripts` against the real envelope
  (`message.content`, `timestamp`, `gitBranch`, `aiTitle`), added the missing
  `cwd` filter, fixed outcome pairing to take the last assistant text block
  per turn, used real 1-based line numbers in event ids, fixed
  `truncate_text`'s bound and multi-`--branch` union/dedup, and switched
  output `ts` to ISO8601 UTC (`...Z`). Tests rewritten against the real
  schema; dogfooded on this repo: 148 events (44 git, 104 session),
  byte-identical across two runs.

* **MCP server**: added [`okf_mcp.py`](/components/mcp-server.md), a read-only
  stdio server over a bundle (`search_concepts`, `read_concept`, `get_neighbors`),
  wired into the plugin by `.mcp.json`. It reverses the July 2026 "no MCP" call on
  positioning grounds only; the original audience argument is intact and recorded
  in the [MCP server decision](/decisions/mcp-server.md). Plugin 0.7.4 to 0.8.0.
* **Skill**: Shipped the `backfill` skill, event-sourcing reconstruction of OKF
  bundles from git history and Claude session transcripts. Extracts events
  deterministically (same repo -> byte-identical events.jsonl); replays via LLM
  interpretation with drift-aware metadata. Designed for repos created before OKF
  adoption to capture their actual decision narrative. Includes a deterministic
  skip-rule classifier (lockfiles, merge-only commits, slash-command noise) and
  cursor-based resume-safe replay loop. Bumped version to 0.9.0.

* **Backfill enhancement**: Deep semantic replay via dedicated agents. New
  `agents/event-analyzer.md` (map phase, parallel)
  extracts domain rationale from git diffs and session outcomes. New
  `agents/bundle-weaver.md` (reduce phase, sequential)
  folds analyses into the bundle while enforcing anti-degeneration rules
  (entity-based naming, kebab-case, intent-driven log). Finalize now includes
  deterministic `--check-coverage` to guarantee every live event is mapped in
  the bundle. Bumped version to 0.9.2.

## 2026-08-16
* **Benchmark returns, measuring something else**: `benchmark/trust/` adds a
  protocol for the one claim the spec leads with and nobody has tested —
  trustability. See [the decision](/decisions/trust-benchmark.md) for why this is
  not what #32 removed. Nothing has been run; the protocol was rejected twice in
  adversarial review (an underpowered criterion, a grader that broke on the most
  likely answer shape, a power analysis whose input did not exist in its own
  calibration data, and a metric undefined exactly where the treatment arm
  concentrates refusals) before being cleared as executable.

## 2026-08-15
* **Distribution**: Published the composite action to the GitHub Marketplace.
  The listing form rejected the shipped metadata — the name `Validate OKF
  bundle` was not globally unique and the description exceeded 125 characters —
  so `action.yml` now reads `OKF Bundle Validator` with a trimmed description
  (v0.7.2). Consumers reference `scaccogatto/okf-skills@<tag>` regardless, so
  the rename breaks nothing.

## 2026-08-03
* **Enforcement**: Made the version bump mandatory. A `version-bump` CI job fails
  any PR that changes the shipped surface (`.claude-plugin/`, `skills/`, `hooks/`,
  `templates/`, `action.yml`) without raising `plugin.json`'s version; docs/`.okf/`
  /tests are exempt and a `skip-version-check` label bypasses it. This closes the
  gap the [auto-release](/decisions/auto-release.md) trigger left: a release now
  can't be skipped by simply forgetting to bump.
* **Decision**: Automated releases. A [`release` workflow](/components/release-workflow.md)
  now tags and publishes `okf--v<version>` whenever a push to `main` changes
  `plugin.json`'s version — releasing was manual and got skipped (0.7.0 and 0.7.1
  were bumped but never released). Recorded in
  [auto-release](/decisions/auto-release.md); cut the missing v0.7.1 release by
  hand.
* **Removal**: Deleted the whole `benchmark/` tree (the with/without run, its
  reframes, and the unrun cross-session "repetition" protocol). Checked the
  canonical spec (Google `knowledge-catalog`, the vendored `SPEC.md`): OKF's
  stated intent (§1) is portable, diffable, *trustable* knowledge exchange — it
  makes no claim about tokens, cost, or answer quality (those words appear zero
  times). The benchmark measured the ecosystem's adoption pitch, not the
  standard, so it does not belong in the toolkit for the standard. Earlier log
  entries mentioning `benchmark/` are left as history.

## 2026-08-02
* **Fix**: [`okf-stop-check.sh`](/components/stop-hook.md) now counts only
  *modified tracked files*, not any untracked path — it false-fired on the
  first real-world trigger (an untracked `.claude/` worktree dir, in this very
  repo). Ignoring all untracked paths fixes the whole class (`.venv/`,
  `.DS_Store`, build dirs) instead of whitelisting one; a new untracked file
  is not yet a documented asset. Also gitignored `.claude/` here as hygiene.
* **Decision**: Recorded [dormant hooks — opt-in enforced
  upkeep](/decisions/dormant-hooks.md) and shipped the plugin's first hook,
  [`okf-stop-check.sh`](/components/stop-hook.md) on `Stop` — a no-op unless a
  bundle sets `upkeep: enforced` in `.okf/index.md` and the user hasn't set
  `OKF_HOOK=off`. This supersedes [ship no hooks](/decisions/no-hooks.md),
  now `deprecated`.

## 2026-07-29
* **Reframe**: The benchmark docs now lead with what the experiment measured —
  answer quality, +8 points with a consistent why/where pattern — and scope the
  token result to what a one-question-per-session design can see, which excludes
  the cross-session repetition cost a bundle is adopted against. That experiment
  ("What to measure next" in `benchmark/results.md`) is specced and unrun; no
  token claim, favourable or not, until it runs. Prompted by
  [#21](https://github.com/scaccogatto/okf-skills/issues/21).
* **Review**: Re-read the vendored spec's §1 intents against the benchmark
  discourse. The tested claim — better answers, cheaper reading — is the
  ecosystem's adoption pitch; the spec stakes v0.2 on trust of agent-written
  corpora, which a pristine bundle never exercises. Added the trust-calibration
  experiment (seeded rot, flat-notes arm) to `benchmark/results.md`, scoped the
  README's selective-reading row to §8's actual promise, and named the tested
  claim's origin in `benchmark/README.md`.

## 2026-07-27
* **Measurement**: Ran the first benchmark of whether a bundle helps an agent —
  12 fresh agents, this repo with and without `.okf/`, blind grading. Result:
  +8 points of claim coverage, **no token saving** (the bundle arm cost 5% more,
  which at n=1 is noise). The bundle won the *why* questions and lost the
  *where-do-I-change-this* one. Recorded in `benchmark/`, and the README's
  progressive-disclosure claim is now qualified by it.
* **Update**: The [visualizer](/components/visualizer.md) now *derives* the §5.3
  trust tier and staleness instead of printing raw dates — the inference v0.2 is
  named for. Both computed at render time; OKF stores neither on purpose.
* **Update**: The [validator](/components/validator.md) gained the §7 actor check
  (aimed at near-misses of `human:`, the one actor typo that silently changes a
  trust tier), `usage_window`, RFC 3339 instants, and resolution of the
  Attested Computation path-valued fields.
* **Distribution**: Added a composite GitHub Action so a bundle can be gated in
  any repo's CI without Claude Code. CI exercises both its passing and failing
  path — an action that never fails would look green for the wrong reason.
* **Update**: Moved the toolkit to [OKF v0.2](/reference/okf-spec.md) — the
  [validator](/components/validator.md) checks the trust, lifecycle, provenance
  and attestation families, the [visualizer](/components/visualizer.md) renders
  them and draws `sources` edges, and [`okf_init.py`](/components/okf_init.md)
  scaffolds v0.2 frontmatter.
* **Decision**: Recorded [target v0.2, migrate v0.1 rather than tolerate
  it](/decisions/okf-v02-dual-read.md) — the legacy read branches buy warning
  wording, not compatibility, so the upgrade path is `--migrate`, not tolerance.
* **Update**: [`okf_validate.py`](/components/validator.md) gained `--migrate`
  (textual v0.1→v0.2 rewrite, idempotent) and `--max-warnings N` between the
  permissive default and `--strict`.
* **Migration**: This bundle moved to v0.2 — `timestamp` became
  `generated: {by, at}`, `# Citations` became `sources`, every concept gained
  `status`.
* **Build**: `make docs` now pins the exact invocation behind the two GitHub
  Pages demos, and CI fails on a stale `docs/`. They had drifted far enough to
  serve a build predating the DOMPurify sanitize fix — a security fix that
  reached the generator but never the pages it was for.
* **Trim**: Dropped the sample bundle's `Attested Computation` demo and the
  executor/attester it pointed at — a demo of a spec feature the toolkit
  implements nowhere.

## 2026-07-17
* **Update**: Added `okf_init.py` — scaffolds a conformant starter bundle
  (`index.md`, `log.md`, a full-frontmatter starter concept). Documented in
  the [okf skill](/skills/okf.md); CI asserts the scaffold passes
  `okf_validate.py --strict` with zero warnings.

## 2026-07-14
* **Scale guardrails**: the [visualizer](/components/visualizer.md) now defaults
  large bundles to a linear layout, warns past 5k concepts, batches/debounces
  filtering, and gains `--max-nodes` — see the
  [scale guardrails decision](/decisions/scale-guardrails.md).

## 2026-06-28
* **Creation**: Documented okf-skills in its own format — the three
  [skills](/skills/okf.md), the [validator](/components/validator.md) and
  [visualizer](/components/visualizer.md) components, the
  [vendored spec](/reference/okf-spec.md), and the architectural decisions
  ([dual distribution](/decisions/dual-distribution.md),
  [no hooks](/decisions/no-hooks.md),
  [self-contained skills](/decisions/self-contained-skills.md)).
