# Learnings: building skogai-core

Notes from the first mod. Each entry records what we found, where it came from, and what it means for the next plugin. Keep appending as we learn more; this is the seed for a larger hooks-and-plugins project.

## Validator rules (`claude plugin validate`)

Verified by running the validator against this mod, build 2.1.289.

- **`on()` takes the event name as a string literal.** A variable (`on(stage, ...)`, looping over a list) fails with "the event name passed to on() is not a string literal". Every event must be written out.
- **The hook must be a function literal.** `on('x', tap('x'))` fails because the hook is a call result. Use `on('x', async ($, e, next) => ...)`.
- **`$` is only used as `$.noun.method(...)`.** Passing `$` to a helper fails. Passing `$.fs` as a value also fails. Calls such as `$.fs.read(...)` inside a closure are fine.
- **Helpers are fine when they don't take `$`.** A module-level queue and a `lineFor(stage, e)` formatter both pass.
- **Good output looks like:** `hooks: <events>` and `calls: $.fs.exists, $.fs.read, $.fs.write, $.ui.status`. The validator lists every event and call it found, which is the quickest way to confirm what a mod does.
- **The `author` warning is harmless.** It appears when `plugin.json` has no author field.

## The file API

From `types/claude-code.d.ts` (`fs` section):

- **No append.** `$.fs.write(path, text)` overwrites the whole file. Appending means read, concatenate, write.
- **Concurrent writes can clobber each other.** Two events firing at once both read the old contents. A module-level promise queue serializes the read-modify-write.
- **4 MiB read limit.** `$.fs.read` rejects over 4 MiB. In 0.4.0 that meant the log's read-and-rewrite append would fail silently once the log grew past it. 0.5.0 avoids `$.fs` for the log entirely: the scripts append with `>>` and the status line reads with `tail -n1`.
- **Paths are relative to the session's working directory,** not the plugin folder. Launch Claude from the repo root, or the log lands somewhere unexpected.

## Hooks and events

- **Pass-through is `return next(e)`.** A hook that returns without `next` answers for the event itself and stops the chain.
- **Streams need a generator.** `turn.step` and `process.spawn` are async generators. A plain `async` hook on them is not what the engine expects, so they are excluded.
- **`ui.render` fires on every redraw.** Logging it floods the file. Filter it, or keep it out.
- **Event names come from the types file.** The input-event list sits in `claude-code.d.ts` as `'<name>': <Name>Input`. Grep it before guessing a name.

## Loading and reloading

- **`--plugin-dir` avoids the enable prompt.** The engine's one-time "Enable hot reloading?" question applies to the dev-mods folder. A `--plugin-dir` folder is watched in an interactive session without it.
- **Reloads reset module variables.** `register` runs again, so the queue starts over. Values in `$.state` and `$.store` survive; plain `let` variables do not.

## Back to plain hooks (0.5.0)

The plugin started as a way to act upon what Claude Code calls hooks, and drifted into a TypeScript mod. 0.5.0 moves the acting back to plain command hooks in `hooks/hooks.json`, one script per event, and keeps a mod only for the status line.

- **One `hooks.json` can hold both.** `"modules"` for the mod and `"hooks"` for command hooks sit side by side, and `claude plugin validate` accepts it.
- **Plain hooks avoid the `$.fs` problems.** The event JSON arrives on stdin, `>>` really appends, and `git rev-parse --show-toplevel` fixes the working-directory problem. No 4 MiB limit, no read-modify-write queue.
- **`$.process.run` has no stdin,** only an argument list, and one Linux argument is capped at 128 KiB. That ruled out a mod that hands events to scripts as arguments.
- **`prompt_id` ties a turn together.** `UserPromptSubmit`, `PostToolUse` and `Stop` all carry it, so `Stop.sh` finds the turn's prompt and tool uses with `grep -F "$prompt_id"` on the log. Subagent rows carry `agent_id` and are skipped.
- **`classic.*` lets a mod follow the plain hooks.** Awaiting `next(e)` before reading the log lets the plain hooks write their row first. Confirmed in an interactive session after `/reload-plugins`.
- **The validator reports `gating hook without .catch: classic.*`.** It's informational. The hook catches its own errors and always returns `next`'s result.
- **Headless check:** `claude -p` in a scratch repo, started from a subdirectory, logged `SessionStart`, `UserPromptSubmit`, `PreToolUse`, `PostToolUse`, `Stop` (with its action) and `SessionEnd`. The journal entry landed at the git root and was staged.
- **Live check (after `/reload-plugins`):** the status line followed the log, and one turn produced `UserPromptSubmit`, `PreToolUse`, `PostToolUse` and `Stop` rows with the same `prompt_id`, plus a journal entry at the git root, staged. `/reload-plugins` was enough to swap 0.4.0 for 0.5.0 mid-session; no restart needed.
- **Subagent check:** one Explore subagent logged `SubagentStart`, its `PreToolUse`/`PostToolUse` rows with `agent_id` and `agent_type`, and `SubagentStop`. Those rows share the parent's `prompt_id`, which is why `Stop.sh` must filter out rows with `agent_id`. Subagent tool calls include the hand-back tool (`SubagentHandback`).
- **`tests/run.sh` tests the scripts without a session.** It writes sample rows with `append-json.sh` into a throwaway repo, runs `Stop.sh`, and checks the log, the journal entry and what got staged.

### Compact, seen live

- `/compact` logs `PreCompact` (`trigger: "manual"`, `custom_instructions`), then `SessionStart` with `source: "compact"`, then `PostCompact` (`compact_summary`). All three carry a `prompt_id`.
- `Notification` fired with `notification_type: "idle_prompt"` about a minute after the turn ended.

### Not done yet

- **`StopFailure`** hasn't been seen live yet (it needs an API error to end a turn).
- **`claude plugin test`** for the status-line mod needs a `*.test.ts` file. The test kit's API is in `docs/plugins/mods/test.md`.

## History: 0.4.0, the all-events mod

0.4.0 logged every event from the mod itself, with one `on()` per event. These notes are kept for what they taught; the events listed are no longer logged.

### Headless check

`claude -p "reply with just OK" --plugin-dir plugins/skogai-core` wrote six lines: `session.start`, `prompt.compose`, `prompt.submit`, `turn.start`, `turn.complete`, `session.end`. The model answered `OK`.

- **Order is what you'd expect:** the session opens, the system prompt is composed, the prompt is submitted, the turn runs, then the session ends.
- **`tool.call` did not fire** because the reply used no tools. A prompt that runs Bash should produce `tool.call` lines.
- **`session.end` carries a `resume` id,** so the log can be joined to the transcript.
- **Headless has no surface.** `surface` is `null` and `isInteractive` is `false`, so the status line can't be seen here. Check it in an interactive session.

### Filling in the rest of the events (build 2.1.295)

Expanded from 10 events to every plain (non-generator) event the validator will register, plus `classic.*`. Checked against `docs/plugins/mods/reference.md` in this repo, then confirmed with `claude plugin validate` and a headless run (`claude -p "run ls" --plugin-dir ...`).

- **`engine.create` can't be hooked the same way as the rest.** It fires while `$` is still being assembled for this mod, so `$.ui.status(...)` inside it threw `undefined is not an object (evaluating '$.ui.status')` and the whole module failed to load with `hooks module did not load: engine.create failed`. One bad hook keeps every hook in the module from registering, not just the one that threw. Dropped it; logging it would need a path that doesn't touch `$.ui` or `$.fs`.
- **`classic.*` works as a literal wildcard.** `on('classic.*', ...)` matched real settings-hook firings (`SessionStart`, `UserPromptSubmit`, `Stop`, ...) in the headless run, each landing as one `"classic.*"` line. `e` is the same stdin JSON a settings hook reads, with `hook_event_name` saying which one it was.
- **Everything else loaded and fired with the same four-line pattern** (`$.ui.status`, read-if-exists, append, `return next(e)`) as the original ten events — no event needed a different return shape just to observe-and-pass-through.
- **High-frequency groups exist beyond the three already known.** `command.describe`, `prompt.section`, `tool.describe`, and `agent.offer` each fired many times in a single turn (once per command/section/tool/subagent-type on offer) but stayed bounded — unlike `ui.render` or the keystroke-path prompt events, they don't need excluding, just expect a burst.
- **`prompt.edit`, `prompt.fill`, `prompt.suggest` were excluded without testing them**, by inference from their one-line descriptions (prompt-box-as-you-type) and `prompt.edit`'s 50ms hook budget in the limits table, which is otherwise only given to hot-path hooks. Worth confirming directly in an interactive session.
