// Process Manager data layer.
//
// This is the ONE seam between the UI and whatever actually runs jobs.
// The UI never touches job data directly — it only calls these methods.
// To route real code behind the screen, implement the same shape in
// createHttpAdapter (or a websocket/IPC adapter) and swap the export at the
// bottom. Nothing in Process Manager.dc.html needs to change.
//
// Adapter contract
// ----------------
//   list()                 -> Promise<Job[]>
//   pause(id)              -> Promise<Job>
//   resume(id)             -> Promise<Job>
//   kill(id)               -> Promise<Job>
//   retry(id)              -> Promise<Job>
//   spawn({name?})         -> Promise<Job>
//   logs(id)               -> Promise<string[]>
//   subscribe(fn)          -> unsubscribe()   // fn(Job[]) on every change
//   meta                   -> { label, transport, live }
//
// Job shape
// ---------
//   { id, name, pid, status, progress, detail, description, startedAt, logs[] }
//   status ∈ 'running' | 'queued' | 'paused' | 'done' | 'failed'

export const STATUS = ['running', 'queued', 'paused', 'done', 'failed'];

const SEED = [
  { id: 1, name: 'sync-worker.sh', pid: 4021, status: 'running', progress: 62, detail: 'syncing shard 3/5', description: 'Replicates local cache against the remote quest ledger.', startedAt: '09:14', logs: ['[09:14:02] boot sequence ok', '[09:14:03] connecting to ledger://sudo-hero', '[09:14:05] shard 1/5 synced', '[09:14:41] shard 2/5 synced', '[09:15:02] shard 3/5 syncing...'] },
  { id: 2, name: 'build-pixel-atlas', pid: 4033, status: 'running', progress: 31, detail: 'packing sprites', description: 'Rebuilds the 16x16 sprite atlas from source PNGs.', startedAt: '09:16', logs: ['[09:16:00] scanning assets/sprites/*', '[09:16:04] found 212 frames', '[09:16:09] packing row 4/12'] },
  { id: 3, name: 'nightly-backup', pid: 3990, status: 'queued', progress: 0, detail: 'waiting on lock', description: 'Snapshots save-state DB to cold storage.', startedAt: '—', logs: ['[queued] waiting for sync-worker.sh to release lock'] },
  { id: 4, name: 'quest-indexer', pid: 3980, status: 'queued', progress: 0, detail: 'position 2 in queue', description: 'Rebuilds the searchable quest index after content patch.', startedAt: '—', logs: ['[queued] position 2'] },
  { id: 5, name: 'patch-v0.9.7', pid: 3921, status: 'done', progress: 100, detail: 'applied cleanly', description: 'Applies the v0.9.7 balance patch to live cabinets.', startedAt: '08:02', logs: ['[08:02:11] patch staged', '[08:03:40] applied to 3 cabinets', '[08:03:41] done ✓'] },
  { id: 6, name: 'leaderboard-flush', pid: 3899, status: 'failed', progress: 44, detail: 'timeout after 30s', description: 'Flushes weekly leaderboard deltas to the scoreboard.', startedAt: '07:40', logs: ['[07:40:00] connecting to scoreboard', '[07:40:30] ETIMEDOUT: no ack from cabinet-cyan', '[07:40:30] job failed ✕'] },
];

const clock = () => {
  const d = new Date();
  return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0') + ':' + String(d.getSeconds()).padStart(2, '0');
};

const wait = (ms) => new Promise(r => setTimeout(r, ms));

// --- Mock adapter: in-memory jobs that actually advance over time ----------
export function createMockAdapter({ latency = 220, tick = 1200 } = {}) {
  let jobs = SEED.map(j => ({ ...j, logs: [...j.logs] }));
  const subs = new Set();
  const emit = () => subs.forEach(fn => fn(jobs.map(j => ({ ...j, logs: [...j.logs] }))));

  const find = (id) => jobs.find(j => j.id === id);
  const patch = (id, fields, logLine) => {
    const j = find(id);
    if (!j) throw new Error(`no such job: ${id}`);
    Object.assign(j, fields);
    if (logLine) j.logs.push(`[${clock()}] ${logLine}`);
    emit();
    return { ...j, logs: [...j.logs] };
  };

  const timer = setInterval(() => {
    let changed = false;
    for (const j of jobs) {
      if (j.status === 'running') {
        j.progress = Math.min(100, j.progress + Math.round(2 + Math.random() * 7));
        changed = true;
        if (j.progress >= 100) {
          j.status = 'done';
          j.detail = 'completed';
          j.logs.push(`[${clock()}] done ✓`);
        }
      }
    }
    // promote a queued job when a worker slot frees up (max 2 concurrent)
    const running = jobs.filter(j => j.status === 'running').length;
    if (running < 2) {
      const next = jobs.find(j => j.status === 'queued');
      if (next) {
        next.status = 'running';
        next.detail = 'worker slot acquired';
        next.startedAt = clock().slice(0, 5);
        next.logs.push(`[${clock()}] started on worker slot`);
        changed = true;
      }
    }
    if (changed) emit();
  }, tick);

  return {
    meta: { label: 'mock://in-memory', transport: 'mock', live: true },
    async list() { await wait(latency); return jobs.map(j => ({ ...j, logs: [...j.logs] })); },
    async logs(id) { await wait(latency / 2); return [...(find(id)?.logs || [])]; },
    async pause(id) { await wait(latency); return patch(id, { status: 'paused', detail: 'paused by user' }, 'SIGSTOP — paused by user'); },
    async resume(id) { await wait(latency); return patch(id, { status: 'running', detail: 'resumed' }, 'SIGCONT — resumed'); },
    async kill(id) { await wait(latency); return patch(id, { status: 'failed', detail: 'killed by user' }, 'SIGKILL — killed by user ✕'); },
    async retry(id) { await wait(latency); return patch(id, { status: 'queued', progress: 0, detail: 're-queued' }, 're-queued for retry'); },
    async spawn({ name } = {}) {
      await wait(latency);
      const id = Math.max(0, ...jobs.map(j => j.id)) + 1;
      const job = {
        id, pid: 4000 + id,
        name: name || `job-${String(id).padStart(3, '0')}.sh`,
        status: 'queued', progress: 0, detail: 'newly spawned',
        description: 'Freshly spawned background job awaiting a worker slot.',
        startedAt: '—', logs: [`[${clock()}] job spawned, awaiting worker`],
      };
      jobs = [job, ...jobs];
      emit();
      return { ...job, logs: [...job.logs] };
    },
    subscribe(fn) { subs.add(fn); return () => subs.delete(fn); },
    dispose() { clearInterval(timer); subs.clear(); },
  };
}

// --- HTTP adapter: the real-code slot ------------------------------------
// Point baseUrl at a service exposing the routes below and it drops straight
// in. Polling stands in for a stream; swap `subscribe` for an EventSource or
// WebSocket when the backend offers one.
export function createHttpAdapter({ baseUrl, poll = 2000, fetchImpl = fetch } = {}) {
  const subs = new Set();
  let timer = null;

  const call = async (path, init) => {
    const res = await fetchImpl(`${baseUrl}${path}`, {
      headers: { 'content-type': 'application/json' },
      ...init,
    });
    if (!res.ok) throw new Error(`${init?.method || 'GET'} ${path} → ${res.status}`);
    return res.status === 204 ? null : res.json();
  };
  const post = (path) => call(path, { method: 'POST' });

  const startPolling = () => {
    if (timer) return;
    timer = setInterval(async () => {
      try { const jobs = await call('/jobs'); subs.forEach(fn => fn(jobs)); }
      catch (err) { subs.forEach(fn => fn(null, err)); }
    }, poll);
  };

  return {
    meta: { label: baseUrl, transport: 'http', live: true },
    list: () => call('/jobs'),                       // GET    /jobs
    logs: (id) => call(`/jobs/${id}/logs`),          // GET    /jobs/:id/logs
    pause: (id) => post(`/jobs/${id}/pause`),        // POST   /jobs/:id/pause
    resume: (id) => post(`/jobs/${id}/resume`),      // POST   /jobs/:id/resume
    kill: (id) => post(`/jobs/${id}/kill`),          // POST   /jobs/:id/kill
    retry: (id) => post(`/jobs/${id}/retry`),        // POST   /jobs/:id/retry
    spawn: (body = {}) => call('/jobs', { method: 'POST', body: JSON.stringify(body) }),
    subscribe(fn) {
      subs.add(fn); startPolling();
      return () => { subs.delete(fn); if (!subs.size) { clearInterval(timer); timer = null; } };
    },
    dispose() { clearInterval(timer); timer = null; subs.clear(); },
  };
}

// Swap this one line to route real code behind the UI:
//   export const adapter = createHttpAdapter({ baseUrl: '/api' });
export const adapter = createMockAdapter();
